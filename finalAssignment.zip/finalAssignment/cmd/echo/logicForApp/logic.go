package logicForApp

import (
	"context"
	"encoding/json"
	"final/cmd/echo/repository"
	"log"
	"strconv"

	"github.com/labstack/echo/v4"
)

func Logout(ctx echo.Context, curUser *int64) echo.HandlerFunc {
	return func(ctx echo.Context) error {
		*curUser = -1
		return ctx.JSON(401, "LOGOUT")
	}
}

//func(username, password string, c echo.Context)
// type GetListsPagePayload struct {
// 	AllListsForUser []repository.GetListsForCurrentUserRow `json:"all"`
// }

func GetLists(ctx echo.Context, curUser *int64, queries *repository.Queries, dbContext *context.Context) echo.HandlerFunc {
	return func(ctx echo.Context) error {

		allListsForCurUser, err := queries.GetListsForCurrentUser(*dbContext, *curUser)
		if err != nil {
			log.Println(err)
		}
		if err != nil {
			log.Println(err)
		}
		return ctx.JSON(200, allListsForCurUser)
	}
}

type listToPost struct {
	Id   int64  `json:"id"`
	Name string `json:"name"`
}

func PostList(ctx echo.Context, curUser *int64, queries *repository.Queries, dbContext *context.Context) echo.HandlerFunc {
	return func(ctx echo.Context) error {

		toAdd := repository.InsertListInDBParams{}
		json.NewDecoder(ctx.Request().Body).Decode(&toAdd)
		toAdd.Userid = *curUser
		log.Println(toAdd)
		added, err := queries.InsertListInDB(*dbContext, toAdd)
		if err != nil {
			log.Println(err)
		}
		log.Println("Added list in db:", added.Name)
		toPost := listToPost{Id: added.IDOfList, Name: added.Name}
		return ctx.JSON(200, toPost)
	}
}

func DeleteList(ctx echo.Context, curUser *int64, queries *repository.Queries, dbContext *context.Context) echo.HandlerFunc {
	return func(ctx echo.Context) error {
		log.Println("ctx param", ctx.Param("id"))
		id, _ := strconv.ParseInt(ctx.Param("id"), 10, 64)
		log.Println("ID to delete is:", id)

		data := queries.DeleteListByID(*dbContext, id)
		return ctx.JSON(200, data)
	}

}
func GetList(ctx echo.Context, curUser *int64, queries *repository.Queries, dbContext *context.Context) echo.HandlerFunc {
	return func(ctx echo.Context) error {
		log.Println("Called get list")
		id, _ := strconv.ParseInt(ctx.Param("id"), 10, 64)
		toGetAllLists, err := queries.GetListsForCurrentUser(*dbContext, *curUser)
		if err != nil {
			log.Println(err)
		}
		var onlyListToGet repository.GetListsForCurrentUserRow
		for _, item := range toGetAllLists {
			if item.IDOfList == id {
				onlyListToGet.IDOfList = item.IDOfList
				onlyListToGet.Name = item.Name
			}
		}
		return ctx.JSON(200, onlyListToGet)
	}

}
